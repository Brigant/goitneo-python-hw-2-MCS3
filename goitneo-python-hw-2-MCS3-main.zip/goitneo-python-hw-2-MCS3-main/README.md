# goitneo-python-hw-1-MCS3

## Congratulator

Congratulator shows the users having birthdays for 7 days from today. But it transfers congratulations to next Monday if the birthday is the weekend.
Just run ```./week_birthdays/congratulator.py``` without import to see an example of execution.

## Bot assistant

This bot can store the contact in RAM using command ```"add [name] [phone]"```. There is a possibilyty to change existen user using command ```"change [name] [phone]"```. You can show a number of specified user by the command ```"phone [name]"``` and you can see all contacs using command ```"all"```.
For runnig but execute ```./bot_assistant/bot.py```.
